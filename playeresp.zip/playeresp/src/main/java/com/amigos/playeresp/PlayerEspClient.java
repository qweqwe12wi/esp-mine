package com.amigos.playeresp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * ESP simples: desenha o nick + distancia de cada jogador na tela,
 * mesmo atras de paredes e muito longe. Funciona so no seu cliente.
 */
public class PlayerEspClient implements ClientModInitializer {

	public static final String MOD_ID = "playeresp";

	@Override
	public void onInitializeClient() {
		HudElementRegistry.attachElementBefore(
				VanillaHudElements.CHAT,
				Identifier.fromNamespaceAndPath(MOD_ID, "player_esp"),
				PlayerEspClient::extract);
	}

	private static void extract(GuiGraphicsExtractor graphics, DeltaTracker tickCounter) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null || mc.options.hideGui) {
			return;
		}

		float partial = tickCounter.getGameTimeDeltaPartialTick(false);

		// Camera = olhos do jogador (em 3a pessoa fica levemente deslocado)
		Vec3 eye = mc.player.getEyePosition(partial);
		double yaw = Math.toRadians(mc.player.getViewYRot(partial));
		double pitch = Math.toRadians(mc.player.getViewXRot(partial));

		// Vetores da camera: frente, direita e cima
		double fx = -Math.sin(yaw) * Math.cos(pitch);
		double fy = -Math.sin(pitch);
		double fz = Math.cos(yaw) * Math.cos(pitch);
		double rx = -Math.cos(yaw);
		double ry = 0.0;
		double rz = -Math.sin(yaw);
		double ux = ry * fz - rz * fy;
		double uy = rz * fx - rx * fz;
		double uz = rx * fy - ry * fx;

		int screenW = mc.getWindow().getGuiScaledWidth();
		int screenH = mc.getWindow().getGuiScaledHeight();
		double aspect = (double) screenW / (double) screenH;
		double tanHalfFov = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);

		for (Player other : mc.level.players()) {
			if (other == mc.player) {
				continue;
			}

			Vec3 pos = other.getPosition(partial);
			// ponto um pouco acima da cabeca
			double tx = pos.x;
			double ty = pos.y + other.getBbHeight() + 0.4;
			double tz = pos.z;

			double dx = tx - eye.x;
			double dy = ty - eye.y;
			double dz = tz - eye.z;

			double depth = dx * fx + dy * fy + dz * fz;
			if (depth < 0.1) {
				continue; // atras de voce
			}

			double ndcX = ((dx * rx + dy * ry + dz * rz) / depth) / (tanHalfFov * aspect);
			double ndcY = ((dx * ux + dy * uy + dz * uz) / depth) / tanHalfFov;
			if (Math.abs(ndcX) > 1.2 || Math.abs(ndcY) > 1.2) {
				continue; // fora da tela
			}

			int sx = (int) (screenW / 2.0 + ndcX * screenW / 2.0);
			int sy = (int) (screenH / 2.0 - ndcY * screenH / 2.0);

			double dist = pos.distanceTo(eye);
			String label = other.getName().getString() + " [" + Math.round(dist) + "m]";

			int w = mc.font.width(label);
			int x = sx - w / 2;
			int y = sy - mc.font.lineHeight;

			graphics.fill(x - 2, y - 1, x + w + 2, y + mc.font.lineHeight, 0x90000000);
			graphics.text(mc.font, label, x, y, 0xFFFFFF55, false);
		}
	}
}
